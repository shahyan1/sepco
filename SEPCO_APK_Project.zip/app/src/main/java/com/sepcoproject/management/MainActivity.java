package com.sepcoproject.management;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 711;
    private static final int REQ_FILE = 801;
    private static final int REQ_TRACK = 712;
    private static final int REQ_NOTIF = 713;
    private static final int REQ_ALL = 714;
    private String pendingApi;
    private String pendingToken;

    private WebView webView;
    private LocationManager locationManager;
    private boolean wantUpdates = false;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                Intent chooser = Intent.createChooser(pick, "Meter photo");
                cameraUri = null;
                try {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        throw new SecurityException("camera permission not granted");
                    }
                    File photo = File.createTempFile("meter_", ".jpg", getCacheDir());
                    cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", photo);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                } catch (Exception ex) {
                    cameraUri = null;
                }
                try {
                    startActivityForResult(chooser, REQ_FILE);
                } catch (Exception ex) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new LocationBridge(), "AndroidLocation");
        webView.loadUrl("file:///android_asset/index.html");
        askPermissions();
    }

    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        ArrayList<String> all = new ArrayList<>();
        all.add(Manifest.permission.ACCESS_FINE_LOCATION);
        all.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        all.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) all.add("android.permission.POST_NOTIFICATIONS");
        for (String p : all) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_ALL);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK) {
                    if (data != null && data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    } else if (cameraUri != null) {
                        results = new Uri[]{cameraUri};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            cameraUri = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final LocationListener sharedListener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            final String js = String.format(Locale.US,
                "window.receiveNativeLocation && window.receiveNativeLocation(%f,%f,%f,%d);",
                loc.getLatitude(), loc.getLongitude(), loc.getAccuracy(), loc.getTime());
            if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
        }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override public void onProviderDisabled(String provider) {
            jsError("Phone Location/GPS was turned off. Turn it on to continue.");
        }
    };

    private void beginUpdates() {
        if (!hasLocationPermission()) {
            jsError("Location permission is not allowed. Allow it in the Android permission popup.");
            return;
        }
        try {
            boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!gps && !network) {
                jsError("Phone Location/GPS is OFF. Turn it ON, then try again.");
                return;
            }
            if (gps) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000L, 5f, sharedListener);
            if (network) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 10f, sharedListener);
            Location last = null;
            if (gps) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null && network) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) sharedListener.onLocationChanged(last);
        } catch (SecurityException ex) {
            jsError("Location permission denied. Allow Location in Android Settings.");
        } catch (Exception ex) {
            jsError("Unable to start GPS. Check phone Location settings.");
        }
    }

    private void stopNativeUpdates() {
        try { if (locationManager != null) locationManager.removeUpdates(sharedListener); } catch (Exception ignored) {}
    }

    private void jsError(String message) {
        if (webView == null) return;
        final String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        webView.post(() -> webView.evaluateJavascript("window.receiveNativeLocationError && window.receiveNativeLocationError('" + safe + "');", null));
    }

    private void launchTracking() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }
        Intent svc = new Intent(this, LocationService.class);
        svc.putExtra("api", pendingApi);
        svc.putExtra("token", pendingToken);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
        else startService(svc);
    }

    private class LocationBridge {
        @JavascriptInterface public void start() {
            runOnUiThread(() -> {
                wantUpdates = true;
                if (hasLocationPermission()) {
                    beginUpdates();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            });
        }
        @JavascriptInterface public void startTracking(String api, String token) {
            runOnUiThread(() -> {
                pendingApi = api;
                pendingToken = token;
                if (hasLocationPermission()) {
                    launchTracking();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_TRACK);
                }
            });
        }
        @JavascriptInterface public void stopTracking() {
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, LocationService.class)));
        }
        @JavascriptInterface public void batterySettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) {}
            });
        }
        @JavascriptInterface public void saveFile(String name, String mime, String content) {
            runOnUiThread(() -> {
                try {
                    byte[] data = content.getBytes("UTF-8");
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        OutputStream os = getContentResolver().openOutputStream(u);
                        os.write(data);
                        os.close();
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        FileOutputStream os = new FileOutputStream(new File(dir, name));
                        os.write(data);
                        os.close();
                    }
                    Toast.makeText(MainActivity.this, "Saved in Downloads: " + name, Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Could not save the file", Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> {
                wantUpdates = false;
                stopNativeUpdates();
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_TRACK) {
            if (hasLocationPermission()) launchTracking();
            else jsError("Location permission denied. Go to Android Settings > Apps > SEPCO Survey Management > Permissions > Location and allow it.");
        }
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) beginUpdates();
            else jsError("Location permission denied. Go to Android Settings > Apps > SEPCO Survey Management > Permissions > Location and allow it.");
        }
    }

    @Override public void onPause() {
        super.onPause();
        stopNativeUpdates();
    }

    @Override public void onResume() {
        super.onResume();
        if (wantUpdates) beginUpdates();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
