package com.sepcoproject.management;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocationService extends Service {
    private static final String CHANNEL = "sepco_duty";
    private static final int NOTIF_ID = 42;
    private static final long SEND_EVERY_MS = 60000L;

    private LocationManager locationManager;
    private String api;
    private String token;
    private long lastSent = 0;
    private boolean updating = false;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) { send(loc); }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String a = intent.getStringExtra("api");
            String t = intent.getStringExtra("token");
            if (a != null) api = a;
            if (t != null) token = t;
        }
        startAsForeground();
        startUpdates();
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Duty location", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        b.setContentTitle("SEPCO duty is ON")
         .setContentText("Sharing live location with admin")
         .setSmallIcon(android.R.drawable.ic_menu_mylocation)
         .setOngoing(true)
         .setContentIntent(open);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void startUpdates() {
        if (updating) return;
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean net = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (gps) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15000L, 10f, listener);
            if (net) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15000L, 20f, listener);
            updating = true;
            Location last = null;
            if (gps) last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null && net) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) send(last);
        } catch (Exception ex) {
            stopSelf();
        }
    }

    private void send(final Location loc) {
        long now = System.currentTimeMillis();
        if (now - lastSent < SEND_EVERY_MS || api == null || token == null) return;
        lastSent = now;
        final String body = String.format(Locale.US,
            "{\"a\":\"loc\",\"t\":\"%s\",\"lat\":\"%f\",\"lon\":\"%f\",\"acc\":\"%f\"}",
            token, loc.getLatitude(), loc.getLongitude(), loc.getAccuracy());
        executor.execute(() -> post(body));
    }

    private void post(String body) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(api).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "text/plain");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.close();
            int code = c.getResponseCode();
            java.io.InputStream is = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                byte[] buf = new byte[1024];
                int r;
                while ((r = is.read(buf)) > 0) sb.append(new String(buf, 0, r, "UTF-8"));
                is.close();
            }
            String resp = sb.toString();
            if (resp.contains("Duty is not started") || resp.contains("\"auth\"")) {
                new Handler(Looper.getMainLooper()).post(() -> stopSelf());
            }
        } catch (Exception ignored) {
            // no internet right now: the next location will try again
        } finally {
            if (c != null) c.disconnect();
        }
    }

    @Override public void onDestroy() {
        try { if (locationManager != null) locationManager.removeUpdates(listener); } catch (Exception ignored) {}
        executor.shutdown();
        super.onDestroy();
    }
}
