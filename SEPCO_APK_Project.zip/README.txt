SEPCO SURVEY MANAGEMENT - ANDROID APK PROJECT (WebView + native GPS + camera)

APK ONLINE BANANE KE STEPS (Android Studio ki zaroorat nahi):
1. github.com par free account banao -> New repository (Private theek hai).
2. Is zip ko pehle EXTRACT karo. Phir saari files aur folders upload karo
   (hidden ".github" folder bhi zaroori hai, usi mein build ki file hai).
3. Repository ke "Actions" tab mein "Build SEPCO APK" chalega (~5-8 minute). Green tick ka intezar karo.
4. Us run par click karo -> neeche "Artifacts" mein SEPCO-Survey-Management-APK download karo (zip).
5. Zip kholo, andar app-debug.apk hai. Phone mein install karo (Install unknown apps allow karna padega).

PEHLI BAAR APP MEIN:
- Server ka /exec link paste karo (Google Apps Script wala), Save link.
- admin / admin se login, phir Account tab se password badlo.
- Location aur Camera maange to Allow karo.

BACKGROUND LOCATION:
- Present dabane par duty ON hoti hai aur status bar mein 'SEPCO duty is ON' notification aata hai. App minimize ya band karne par bhi location har 1 minute mein admin ko jati hai.
- Notification permission maange to Allow karo. Location 'Allow' (While using the app ya Allow all the time) dono chalte hain.
- Phone ki Battery settings mein SEPCO ko 'Unrestricted' / 'No restrictions' karo (app ke Today tab mein button hai), warna kuch phones (Oppo, Vivo, Xiaomi, Realme) background app band kar dete hain.
- Duty End ya Sign out karne par location band ho jati hai.

PERMISSIONS (pehli baar app kholte hi popup aate hain): Location, Camera, Notifications - teeno Allow karo.
Files (CSV/backup) phone ke Downloads folder mein save hoti hain.
